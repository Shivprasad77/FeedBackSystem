package com.example.demo.model;
import jakarta.persistence.*;


@Entity
@Table(name = "Feedback")
public class Feedback {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "BatchCode")
    private String batchcode;

    @Column(name = "Rating")
    private String rating;

    @Column(name = "Comments")
    private String comments;
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public String getBathCode() {
        return batchcode;
    }
    public void setBatchCode(String batchcode) {
        this.batchcode = batchcode;
    }
    public String getRating() {
        return rating;
    }
    public void setRating(String rating) {
        this.rating = rating;
    }
    public String getComments() {
        return comments;
    }
    public void setComments(String comments) {
    
    	this.comments=comments;
    }
  
}			